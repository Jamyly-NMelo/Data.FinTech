import React from 'react';
import { CalendarClock, CalendarPlus } from 'lucide-react';
import EmptyState from '@/components/common/EmptyState';
import Money from '@/components/common/Money';
import SectionCard from '@/components/common/SectionCard';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/format';

function buildGoogleCalendarUrl(item, isoDate) {
  const cleanDate = String(isoDate || '').slice(0, 10).replace(/-/g, '');
  if (cleanDate.length !== 8) return null;

  const year = Number(cleanDate.slice(0, 4));
  const month = Number(cleanDate.slice(4, 6)) - 1;
  const day = Number(cleanDate.slice(6, 8));
  const next = new Date(year, month, day + 1);
  const nextDate = [
    String(next.getFullYear()),
    String(next.getMonth() + 1).padStart(2, '0'),
    String(next.getDate()).padStart(2, '0'),
  ].join('');

  const prefix = item.kind === 'income' ? 'Recebimento' : 'Pagamento';
  const title = `Data.FinTech • ${prefix}: ${item.description || 'Lançamento financeiro'}`;
  const details = 'Lembrete financeiro criado a partir da sua agenda no Data.FinTech.';

  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: title,
    dates: `${cleanDate}/${nextDate}`,
    details,
  });

  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

export default function AgendaPanel({ agenda = [], days = 10 }) {
  return (
    <SectionCard title="Agenda financeira" description={`Contas a pagar e receber nos próximos ${days} dias.`}>
      {agenda.length === 0 ? (
        <EmptyState compact icon={CalendarClock} title="Agenda livre" description="Nenhum lançamento em aberto nessa janela." />
      ) : (
        <div className="max-h-80 space-y-3 overflow-y-auto">
          {agenda.map((group) => (
            <section key={group.date} className="space-y-2">
              <div className="flex items-center justify-between gap-3 text-xs">
                <h3 className="font-semibold">{formatDate(group.date)}</h3>
                <Badge variant={group.net >= 0 ? 'secondary' : 'outline'}>
                  saldo <Money value={group.net} colored />
                </Badge>
              </div>
              <ul className="space-y-1.5">
                {group.items.map((item) => {
                  const calendarUrl = buildGoogleCalendarUrl(item, group.date);
                  return (
                    <li key={item.id} className="flex items-center justify-between gap-2 rounded-lg bg-muted/40 px-3 py-2 text-xs">
                      <span className="min-w-0 flex-1 truncate">{item.description}</span>
                      <span className="shrink-0">{item.kind === 'income' ? '+' : '−'}<Money value={item.open_amount} colored /></span>
                      {calendarUrl ? (
                        <a
                          href={calendarUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          title="Adicionar ao Google Agenda"
                          aria-label={`Adicionar ${item.description} ao Google Agenda`}
                          className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                        >
                          <CalendarPlus className="h-3.5 w-3.5" />
                        </a>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      )}
    </SectionCard>
  );
}
